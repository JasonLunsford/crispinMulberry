//--------------------------------
// NAT Challenge Carousel Plug-in
// Jason Lunsford
// v1.0
// natCarousel.js
//--------------------------------
// Usage:
// $("#carouselRoot").natCarousel("fast","reverse");
// 
// Default Values: normal, forward

(function ( $ ) {
	$.fn.natCarousel = function( options ) {
	
		var opts = $.extend( {}, $.fn.natCarousel.defaults, options );
		
		// Configure the film strip that contains the large images
		var filmStripWidth = 0;
		$(".largePictureBox").find("img").each(function() {
			var $this = $( this );
			filmStripWidth = filmStripWidth + $(this).width();
		});
		$(".filmStrip").width(filmStripWidth);
		
		
		// Configure the thumbnail to large pic association
		return $(".smallPictureRow").find("img").each(function() {
			var $this = $( this );
			
			$this.on("click", function() {
				var tempVal = $(this).attr("id");
				thumbValue = tempVal.substr(1,1);

				if ( thumbValue == "1" ) {
					$(".filmStrip").css("left","0px");
					$("#focusArrow").css("left","0px");
				}
				else if ( thumbValue == "2" ) {
					$(".filmStrip").css("left","-666px");
					$("#focusArrow").css("left","169px");
				}
				else if ( thumbValue == "3" ) {
					$(".filmStrip").css("left","-1332px");
					$("#focusArrow").css("left","338px");
				}
				else if ( thumbValue == "4" ) {
					$(".filmStrip").css("left","-1998px");
					$("#focusArrow").css("left","507px");
				}
			});
		});
	};
	
	$.fn.natCarousel.defaults = {
		speed:"normal",
		direction:"forward"
	};
}( jQuery ));